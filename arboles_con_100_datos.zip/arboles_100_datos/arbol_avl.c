#include <stdio.h>
#include <stdlib.h>

#define MAX_DATOS 100
#define MAX_PREFIJO 512

typedef struct NodoAVL {
    int dato;
    int altura;
    struct NodoAVL *izquierda;
    struct NodoAVL *derecha;
} NodoAVL;

int mayor(int a, int b) {
    if (a > b) {
        return a;
    }
    return b;
}

int altura(NodoAVL *nodo) {
    if (nodo == NULL) {
        return 0;
    }
    return nodo->altura;
}

int factorEquilibrio(NodoAVL *nodo) {
    if (nodo == NULL) {
        return 0;
    }
    return altura(nodo->izquierda) - altura(nodo->derecha);
}

NodoAVL *crearNodo(int dato) {
    NodoAVL *nuevo;

    nuevo = (NodoAVL *)malloc(sizeof(NodoAVL));
    if (nuevo == NULL) {
        printf("Error: no hay memoria suficiente.\n");
        exit(1);
    }

    nuevo->dato = dato;
    nuevo->altura = 1;
    nuevo->izquierda = NULL;
    nuevo->derecha = NULL;
    return nuevo;
}

NodoAVL *rotacionDerecha(NodoAVL *y) {
    NodoAVL *x;
    NodoAVL *temporal;

    x = y->izquierda;
    temporal = x->derecha;

    x->derecha = y;
    y->izquierda = temporal;

    y->altura = mayor(altura(y->izquierda), altura(y->derecha)) + 1;
    x->altura = mayor(altura(x->izquierda), altura(x->derecha)) + 1;

    return x;
}

NodoAVL *rotacionIzquierda(NodoAVL *x) {
    NodoAVL *y;
    NodoAVL *temporal;

    y = x->derecha;
    temporal = y->izquierda;

    y->izquierda = x;
    x->derecha = temporal;

    x->altura = mayor(altura(x->izquierda), altura(x->derecha)) + 1;
    y->altura = mayor(altura(y->izquierda), altura(y->derecha)) + 1;

    return y;
}

NodoAVL *insertar(NodoAVL *raiz, int dato) {
    int equilibrio;

    if (raiz == NULL) {
        return crearNodo(dato);
    }

    if (dato < raiz->dato) {
        raiz->izquierda = insertar(raiz->izquierda, dato);
    } else if (dato > raiz->dato) {
        raiz->derecha = insertar(raiz->derecha, dato);
    } else {
        return raiz;
    }

    raiz->altura = 1 + mayor(altura(raiz->izquierda), altura(raiz->derecha));
    equilibrio = factorEquilibrio(raiz);

    /* Caso izquierda-izquierda */
    if (equilibrio > 1 && dato < raiz->izquierda->dato) {
        return rotacionDerecha(raiz);
    }

    /* Caso derecha-derecha */
    if (equilibrio < -1 && dato > raiz->derecha->dato) {
        return rotacionIzquierda(raiz);
    }

    /* Caso izquierda-derecha */
    if (equilibrio > 1 && dato > raiz->izquierda->dato) {
        raiz->izquierda = rotacionIzquierda(raiz->izquierda);
        return rotacionDerecha(raiz);
    }

    /* Caso derecha-izquierda */
    if (equilibrio < -1 && dato < raiz->derecha->dato) {
        raiz->derecha = rotacionDerecha(raiz->derecha);
        return rotacionIzquierda(raiz);
    }

    return raiz;
}

/* Imprime cada nodo con ramas ASCII para que la estructura se entienda mejor. */
void mostrarRama(NodoAVL *nodo, const char *prefijo, int esUltimo, const char *lado) {
    char nuevoPrefijo[MAX_PREFIJO];
    int tieneIzquierda;
    int tieneDerecha;

    if (nodo == NULL) {
        return;
    }

    printf("%s%s%s%d [altura=%d, FE=%d]\n",
           prefijo,
           esUltimo ? "\\-- " : "|-- ",
           lado,
           nodo->dato,
           nodo->altura,
           factorEquilibrio(nodo));

    snprintf(nuevoPrefijo, sizeof(nuevoPrefijo), "%s%s",
             prefijo, esUltimo ? "    " : "|   ");

    tieneIzquierda = (nodo->izquierda != NULL);
    tieneDerecha = (nodo->derecha != NULL);

    if (tieneIzquierda && tieneDerecha) {
        mostrarRama(nodo->izquierda, nuevoPrefijo, 0, "IZQ: ");
        mostrarRama(nodo->derecha, nuevoPrefijo, 1, "DER: ");
    } else if (tieneIzquierda) {
        mostrarRama(nodo->izquierda, nuevoPrefijo, 1, "IZQ: ");
    } else if (tieneDerecha) {
        mostrarRama(nodo->derecha, nuevoPrefijo, 1, "DER: ");
    }
}

void mostrarArbol(NodoAVL *raiz) {
    int tieneIzquierda;
    int tieneDerecha;

    if (raiz == NULL) {
        printf("El arbol esta vacio.\n");
        return;
    }

    printf("RAIZ: %d [altura=%d, FE=%d]  <--- NODO RAIZ\n",
           raiz->dato, raiz->altura, factorEquilibrio(raiz));

    tieneIzquierda = (raiz->izquierda != NULL);
    tieneDerecha = (raiz->derecha != NULL);

    if (tieneIzquierda && tieneDerecha) {
        mostrarRama(raiz->izquierda, "", 0, "IZQ: ");
        mostrarRama(raiz->derecha, "", 1, "DER: ");
    } else if (tieneIzquierda) {
        mostrarRama(raiz->izquierda, "", 1, "IZQ: ");
    } else if (tieneDerecha) {
        mostrarRama(raiz->derecha, "", 1, "DER: ");
    }
}

void liberarArbol(NodoAVL *raiz) {
    if (raiz == NULL) {
        return;
    }
    liberarArbol(raiz->izquierda);
    liberarArbol(raiz->derecha);
    free(raiz);
}

int main(void) {
    FILE *archivo;
    NodoAVL *raiz;
    int cantidad;
    int dato;
    int i;

    raiz = NULL;
    archivo = fopen("datos.txt", "r");

    if (archivo == NULL) {
        printf("No se pudo abrir datos.txt. Coloca el archivo en la misma carpeta del programa.\n");
        return 1;
    }

    if (fscanf(archivo, "%d", &cantidad) != 1 || cantidad < 1 || cantidad > MAX_DATOS) {
        printf("El archivo debe comenzar con una cantidad entre 1 y %d.\n", MAX_DATOS);
        fclose(archivo);
        return 1;
    }

    for (i = 0; i < cantidad; i++) {
        if (fscanf(archivo, "%d", &dato) != 1) {
            printf("Error: faltan datos en datos.txt. Se esperaban %d numeros.\n", cantidad);
            fclose(archivo);
            liberarArbol(raiz);
            return 1;
        }
        raiz = insertar(raiz, dato);
    }

    fclose(archivo);

    printf("============================================================\n");
    printf("                    ARBOL AVL\n");
    printf("============================================================\n");
    printf("Numeros leidos desde datos.txt: %d\n", cantidad);
    printf("La raiz es el primer nodo mostrado y esta marcada como NODO RAIZ.\n");
    printf("IZQ = hijo izquierdo (valor menor) | DER = hijo derecho (valor mayor)\n");
    printf("|-- y \\-- muestran las conexiones entre los nodos.\n\n");
    mostrarArbol(raiz);

    liberarArbol(raiz);
    return 0;
}
