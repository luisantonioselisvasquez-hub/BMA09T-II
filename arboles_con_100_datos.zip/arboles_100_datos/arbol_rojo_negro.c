#include <stdio.h>
#include <stdlib.h>

#define MAX_DATOS 100
#define MAX_PREFIJO 512
#define ROJO 1
#define NEGRO 0

typedef struct NodoRN {
    int dato;
    int color;
    struct NodoRN *izquierda;
    struct NodoRN *derecha;
    struct NodoRN *padre;
} NodoRN;

NodoRN *NIL;

NodoRN *crearNodo(int dato) {
    NodoRN *nuevo;

    nuevo = (NodoRN *)malloc(sizeof(NodoRN));
    if (nuevo == NULL) {
        printf("Error: no hay memoria suficiente.\n");
        exit(1);
    }

    nuevo->dato = dato;
    nuevo->color = ROJO;
    nuevo->izquierda = NIL;
    nuevo->derecha = NIL;
    nuevo->padre = NIL;
    return nuevo;
}

void rotacionIzquierda(NodoRN **raiz, NodoRN *x) {
    NodoRN *y;

    y = x->derecha;
    x->derecha = y->izquierda;

    if (y->izquierda != NIL) {
        y->izquierda->padre = x;
    }

    y->padre = x->padre;

    if (x->padre == NIL) {
        *raiz = y;
    } else if (x == x->padre->izquierda) {
        x->padre->izquierda = y;
    } else {
        x->padre->derecha = y;
    }

    y->izquierda = x;
    x->padre = y;
}

void rotacionDerecha(NodoRN **raiz, NodoRN *y) {
    NodoRN *x;

    x = y->izquierda;
    y->izquierda = x->derecha;

    if (x->derecha != NIL) {
        x->derecha->padre = y;
    }

    x->padre = y->padre;

    if (y->padre == NIL) {
        *raiz = x;
    } else if (y == y->padre->derecha) {
        y->padre->derecha = x;
    } else {
        y->padre->izquierda = x;
    }

    x->derecha = y;
    y->padre = x;
}

void corregirInsercion(NodoRN **raiz, NodoRN *z) {
    NodoRN *tio;

    while (z->padre->color == ROJO) {
        if (z->padre == z->padre->padre->izquierda) {
            tio = z->padre->padre->derecha;

            if (tio->color == ROJO) {
                z->padre->color = NEGRO;
                tio->color = NEGRO;
                z->padre->padre->color = ROJO;
                z = z->padre->padre;
            } else {
                if (z == z->padre->derecha) {
                    z = z->padre;
                    rotacionIzquierda(raiz, z);
                }
                z->padre->color = NEGRO;
                z->padre->padre->color = ROJO;
                rotacionDerecha(raiz, z->padre->padre);
            }
        } else {
            tio = z->padre->padre->izquierda;

            if (tio->color == ROJO) {
                z->padre->color = NEGRO;
                tio->color = NEGRO;
                z->padre->padre->color = ROJO;
                z = z->padre->padre;
            } else {
                if (z == z->padre->izquierda) {
                    z = z->padre;
                    rotacionDerecha(raiz, z);
                }
                z->padre->color = NEGRO;
                z->padre->padre->color = ROJO;
                rotacionIzquierda(raiz, z->padre->padre);
            }
        }
    }

    (*raiz)->color = NEGRO;
}

void insertar(NodoRN **raiz, int dato) {
    NodoRN *nuevo;
    NodoRN *anterior;
    NodoRN *actual;

    anterior = NIL;
    actual = *raiz;

    while (actual != NIL) {
        anterior = actual;
        if (dato < actual->dato) {
            actual = actual->izquierda;
        } else if (dato > actual->dato) {
            actual = actual->derecha;
        } else {
            return;
        }
    }

    nuevo = crearNodo(dato);
    nuevo->padre = anterior;

    if (anterior == NIL) {
        *raiz = nuevo;
    } else if (dato < anterior->dato) {
        anterior->izquierda = nuevo;
    } else {
        anterior->derecha = nuevo;
    }

    corregirInsercion(raiz, nuevo);
}

/* Imprime cada nodo con ramas ASCII y conserva su color. */
void mostrarRama(NodoRN *nodo, const char *prefijo, int esUltimo, const char *lado) {
    char nuevoPrefijo[MAX_PREFIJO];
    int tieneIzquierda;
    int tieneDerecha;

    if (nodo == NIL) {
        return;
    }

    printf("%s%s%s%d [%s]\n",
           prefijo,
           esUltimo ? "\\-- " : "|-- ",
           lado,
           nodo->dato,
           nodo->color == ROJO ? "ROJO" : "NEGRO");

    snprintf(nuevoPrefijo, sizeof(nuevoPrefijo), "%s%s",
             prefijo, esUltimo ? "    " : "|   ");

    tieneIzquierda = (nodo->izquierda != NIL);
    tieneDerecha = (nodo->derecha != NIL);

    if (tieneIzquierda && tieneDerecha) {
        mostrarRama(nodo->izquierda, nuevoPrefijo, 0, "IZQ: ");
        mostrarRama(nodo->derecha, nuevoPrefijo, 1, "DER: ");
    } else if (tieneIzquierda) {
        mostrarRama(nodo->izquierda, nuevoPrefijo, 1, "IZQ: ");
    } else if (tieneDerecha) {
        mostrarRama(nodo->derecha, nuevoPrefijo, 1, "DER: ");
    }
}

void mostrarArbol(NodoRN *raiz) {
    int tieneIzquierda;
    int tieneDerecha;

    if (raiz == NIL) {
        printf("El arbol esta vacio.\n");
        return;
    }

    printf("RAIZ: %d [%s]  <--- NODO RAIZ\n",
           raiz->dato, raiz->color == ROJO ? "ROJO" : "NEGRO");

    tieneIzquierda = (raiz->izquierda != NIL);
    tieneDerecha = (raiz->derecha != NIL);

    if (tieneIzquierda && tieneDerecha) {
        mostrarRama(raiz->izquierda, "", 0, "IZQ: ");
        mostrarRama(raiz->derecha, "", 1, "DER: ");
    } else if (tieneIzquierda) {
        mostrarRama(raiz->izquierda, "", 1, "IZQ: ");
    } else if (tieneDerecha) {
        mostrarRama(raiz->derecha, "", 1, "DER: ");
    }
}

void liberarArbol(NodoRN *raiz) {
    if (raiz == NIL) {
        return;
    }
    liberarArbol(raiz->izquierda);
    liberarArbol(raiz->derecha);
    free(raiz);
}

int main(void) {
    FILE *archivo;
    NodoRN *raiz;
    int cantidad;
    int dato;
    int i;

    NIL = (NodoRN *)malloc(sizeof(NodoRN));
    if (NIL == NULL) {
        printf("Error: no hay memoria suficiente.\n");
        return 1;
    }
    NIL->color = NEGRO;
    NIL->izquierda = NIL;
    NIL->derecha = NIL;
    NIL->padre = NIL;

    raiz = NIL;
    archivo = fopen("datos.txt", "r");

    if (archivo == NULL) {
        printf("No se pudo abrir datos.txt. Coloca el archivo en la misma carpeta del programa.\n");
        free(NIL);
        return 1;
    }

    if (fscanf(archivo, "%d", &cantidad) != 1 || cantidad < 1 || cantidad > MAX_DATOS) {
        printf("El archivo debe comenzar con una cantidad entre 1 y %d.\n", MAX_DATOS);
        fclose(archivo);
        free(NIL);
        return 1;
    }

    for (i = 0; i < cantidad; i++) {
        if (fscanf(archivo, "%d", &dato) != 1) {
            printf("Error: faltan datos en datos.txt. Se esperaban %d numeros.\n", cantidad);
            fclose(archivo);
            liberarArbol(raiz);
            free(NIL);
            return 1;
        }
        insertar(&raiz, dato);
    }

    fclose(archivo);

    printf("============================================================\n");
    printf("                 ARBOL ROJO-NEGRO\n");
    printf("============================================================\n");
    printf("Numeros leidos desde datos.txt: %d\n", cantidad);
    printf("La raiz es el primer nodo mostrado y esta marcada como NODO RAIZ.\n");
    printf("IZQ = hijo izquierdo (valor menor) | DER = hijo derecho (valor mayor)\n");
    printf("[ROJO] y [NEGRO] indican el color de cada nodo.\n");
    printf("|-- y \\-- muestran las conexiones entre los nodos.\n\n");
    mostrarArbol(raiz);

    liberarArbol(raiz);
    free(NIL);
    return 0;
}
